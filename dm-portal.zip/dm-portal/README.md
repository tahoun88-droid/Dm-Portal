# DM Portal

Free PWA demo for department workflow:
- Login demo users
- PM raises requests to Head of Department
- HOD decides or recommends/escalates to Director
- Director sees only escalated decisions
- LocalStorage persistence

## Run locally
```bash
npm install
npm run dev
```

## Deploy on Vercel
Import this GitHub repo in Vercel and deploy.
